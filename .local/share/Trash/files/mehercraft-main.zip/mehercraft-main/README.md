# mehercraft

This is the Grub bootloader  theme. Kindly clone this directory and run the script setup.sh
