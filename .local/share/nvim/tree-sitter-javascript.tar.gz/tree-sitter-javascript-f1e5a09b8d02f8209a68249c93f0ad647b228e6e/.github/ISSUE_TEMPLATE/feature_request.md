---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

<!--
     The tree-sitter-javascript project is a JavaScript and JSX parser only.
     How can we improve it?
-->
