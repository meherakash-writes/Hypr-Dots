# tree-sitter-html

[![build](https://github.com/tree-sitter/tree-sitter-html/actions/workflows/ci.yml/badge.svg)](https://github.com/tree-sitter/tree-sitter-html/actions/workflows/ci.yml)

HTML grammar for [tree-sitter](https://github.com/tree-sitter/tree-sitter).

References

* [The HTML5 Spec](https://www.w3.org/TR/html5/syntax.html)
