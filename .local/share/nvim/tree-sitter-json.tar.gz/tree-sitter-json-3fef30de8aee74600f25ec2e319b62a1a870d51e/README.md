# tree-sitter-json

[![CI](https://github.com/tree-sitter/tree-sitter-json/actions/workflows/ci.yml/badge.svg)](https://github.com/tree-sitter/tree-sitter-json/actions/workflows/ci.yml)

JSON grammar for [tree-sitter](https://github.com/tree-sitter/tree-sitter)
