The best resolution should be 1280x1024 to be installed in grub (my screen 1920x1080)

Concerning grub : 

if you think that you need to install other font just go to the following adress :
https://forum.ubuntu-fr.org/viewtopic.php?id=1940901

important
after installing the grub theme range the additional background (..._intermediary_grub.png) in :/boot/grub
